/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird; // imports the package flappybird
import javax.swing.JPanel; // imports the jpanel which is the window
import java.awt.Graphics;// mports the graphics

public class Renderer extends JPanel
{
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void paintComponent(Graphics g) // graphics used to render the screen as well as used to display the colors/font and graphic elements on the scree.
    {
        super.paintComponent(g);// color component whcih was used throughtout in the game window
        
        FlappyBird.flappyBird.repaint(g);// allows the programer to fill the main code section with color. 
    }
}
