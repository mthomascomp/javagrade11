
// Done By: Mervin Thomas, Myles Vita-Finzi, and Ifeoluwa Gbenga-Alade
// Instructor Name : Mr. Kyle Batterink 
// Course Code: ICS3U-b
// Due Date: June 3, 2016 
// prject title: Final Project - Flappy Bird 

// The process, challenges, and time frame is mentioned at the very end of theis program. 

//Instructions: 
// Press the spacebar or click the mouse to begin the game. One the game is over you can click the spacebar or the mouse to start again. 
// results and refelections at the end of the program.

package flappybird;// THe main packagae/project of the game. 

// import of the nessecary elements for the program to run
import java.awt.Color; //imported color graphics to java which will be used later in the program
import java.awt.Font; // Imported font information into java, used to display text onto the screen
import java.awt.Graphics; //Imported graphics onto Java. Allows us to display boxes and other graphic material to the user. 
import java.awt.Rectangle; //This rectangle import function allows the creator to insert boxes into the screen. Very essential for the flappybird tower. 
import java.awt.event.ActionEvent;// This import allows 
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent; //Keyboard functions
import java.awt.event.KeyListener;//keyborad functions
import java.awt.event.MouseEvent; //mouse functions
import java.awt.event.MouseListener; //mouse function
import java.util.ArrayList;
import java.util.Random; //Random command / function
import javax.swing.JFrame; //Imports J frame. This is bascially the spinal cord of this game. 
import javax.swing.Timer; // timer import used to calculate and make the game run smooth. Used later on. 

// the main coding section of the game of flappy bird, whcih implement the mouse and the keybard 
public class FlappyBird implements ActionListener, MouseListener, KeyListener // this line of code implments the mouse and the keyboard feature for the project. 
{

	public static FlappyBird flappyBird;

	public final int WIDTH = 800, HEIGHT = 800; // Sets the size of the window frame with 800 X 800 
  
	public Renderer renderer; // New class within this project. Class name is renderer. Also this line of code helps create a new variable
       
	public Rectangle bird; // creates a rectangle for the bird/box. 

	public ArrayList<Rectangle> columns; // Creates a array list for the columns. 

	public int ticks, yMotion, score; // makes the y motion, the score ad the ticks in public integer form. Meaning these variables are related to numbers

	public boolean gameOver, started; // Boolean operations for the variable game over and started

	public Random rand; // made a public name for random 

	public FlappyBird() //start of the commands for the game flappy bird itself
	{
                // Lines 51-63 contain the jframe elements of this game and also a new class which is used to render the game screen to the user. 
		JFrame jframe = new JFrame(); // This line of code created the J frame. 
		Timer timer = new Timer(20, this);//sets the timer for the game. 
		renderer = new Renderer(); // sets the renderer as a new variable 
		rand = new Random();// random function for the project. Used to randomize the columns in the game which is programed later on. 
		jframe.add(renderer); // This line of code adds the renderer command and class from this project. 
		jframe.setTitle("Final Project - Flappy Bird ");// Prints the title of flappy bird 
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setSize(WIDTH, HEIGHT); // Sets the variable of width and height
		jframe.addMouseListener(this);//adds the mouse feature to the program. The extension is also added at the end of the program.
		jframe.addKeyListener(this); // adds the keyboard feature to the program and also the extension is added at the end of the program.
		jframe.setResizable(false);//Does not allow the screen display to be resizable. The user cannot change the display size. 
		jframe.setVisible(true); // Allows the display renderer to be visible. 
               
		bird = new Rectangle(WIDTH / 2 - 10, HEIGHT / 2 - 10, 20, 20); //Gives a new command for the appropriate measurments for the width and the height of the bird
		columns = new ArrayList<Rectangle>();// This line of code provides the columns which appear in the flappy bird game. 

		addColumn(true);// Four columns are added in each game frame. 
		addColumn(true); //Four columns are added in each game frame. 
		addColumn(true);//Four columns are added in each game frame. 
		addColumn(true);//Four columns are added in each game frame. 

		timer.start(); // After the follwing commands have been followed then the timer will start, and the timer will start if the key or the mousepad has been pressed.
	}

	public void addColumn(boolean start)//Starts the boolean operation command in this public void section of the code
	{
		int space = 300; // sets the space of the integers to 300
		int width = 100;//  sets the width of the integers to 100
		int height = 50 + rand.nextInt(300); //

		if (start)// if command. The programs under this loop will only run if the game is started
		{
			columns.add(new Rectangle(WIDTH + width + columns.size() * 300, HEIGHT - height - 120, width, height)); //This line of code basically tells us that if the game is started it will produce new columsn with the size, that is mentioned with the given numbers. 
                        //the above line of code also renders to the number of columns that are provided in the bottom. 
			columns.add(new Rectangle(WIDTH + width + (columns.size() - 1) * 300, 0, width, HEIGHT - height - space)); // This line of code bascially renders to the columns that are produced in the top. 
		}
                else // else command 
		{
			columns.add(new Rectangle(columns.get(columns.size() - 1).x + 600, HEIGHT - height - 120, width, height));//This line of code allows the column to remain stationery if the game has not started.
			columns.add(new Rectangle(columns.get(columns.size() - 1).x, 0, width, HEIGHT - height - space));//This line of code allows the column to remain stationery if the game has not started.
		}
	}

	public void paintColumn(Graphics g, Rectangle column) // Provides the paint and the graphic functions for the columns that are provided on the screen. 
	{
		g.setColor(Color.yellow.darker()); // This allows the base of the game plane to be yellow in a dark shade.This can be change. 
                //The above line of code is possible because of the import function of the graphic and color which was put at the start of this program.
		g.fillRect(column.x, column.y, column.width, column.height); // This fills rectangle with the dark yellow color.
	}
        


	public void jump() //Starts a new public void section for the jump section. 
	{
		if (gameOver) // if command. In this case if the game is started then the following commands will run. 
		{
			bird = new Rectangle(WIDTH / 2 - 10, HEIGHT / 2 - 10, 20, 20); // Set the new measuremnts for the bird. In other words if the game is over then the bird will go away slowly
                        columns.clear(); // This command will also allow the the columns/pillars in the game to keep going in the game
			yMotion = 0; // the motion or the movement of the object will be none in both the y and x direction
			score = 0; // the motion or the movement of the object will be none in both the y and x direction

			addColumn(true);// Four columns are added in each game frame. 
			addColumn(true);// Four columns are added in each game frame. 
			addColumn(true);// Four columns are added in each game frame. 
			addColumn(true);// Four columns are added in each game frame. 

			gameOver = false; // this line of code provides with the gameover false, will be used later in the code. 
		}

		if (!started) // Follows the if statment if the game has not started 
		{
			started = true; // If started variable is true.
		}
		else if (!gameOver) // if the game is not over
		{
			if (yMotion > 0) // Renders to the y motion and if it is greate than 0
			{
				yMotion = 0; // Will put the y motion speed to 0 
			}

			yMotion -= 10; //this line of code falls under the elif command and basicaly means that the ymotion will be -= to 10. 
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)// this command/loop will run for the action performed by the game, in other word these command cater to when the game has started playing. 
	{
		int speed = 10; // Sets the speed of the object dodging the pillar

		ticks++; // The ++ means double add. In this case ticks is added two times. 

		if (started) // if the game has started
		{
			for (int i = 0; i < columns.size(); i++) //gave range for variable i as used in python. ++ means add double or add twice for the range. 
			{
				Rectangle column = columns.get(i);

				column.x -= speed; //gives a coniditon for the x columns in the for loop. 
			}

			if (ticks % 2 == 0 && yMotion < 15) // this line of code basically says how if the ticks are not equalt to 0 and the y motion is < 15 then the y motion is equal to 2 
			{
				yMotion += 2; //This line of code only follows if the program has entered the if loop.
			}

			for (int i = 0; i < columns.size(); i++) //for loop. This line of code shows how the integer 1 is equal to 0 and also if 1 < columns, and also double the 1 with the ++ sign
			{
				Rectangle column = columns.get(i); // this line of code falls under the for loop 

				if (column.x + column.width < 0) // this line of code has the if command statement. It basically says if the columns and the width is lessa than zero
				{
					columns.remove(column); // this line of code falls under the if command. This will basically remove the columns in the game frame.

					if (column.y == 0) // this is a if command and which basically says that if the y column if == to 0 then it follow the command underneath it 
					{
						addColumn(false); // This line basically says that adding an another column is false, or the program will not add another y column to the game frame. 
					}
				}
			}

			bird.y += yMotion;// motion of the bird in the y direction which is controlled by the spacebar/the mouse. 

			for (Rectangle column : columns) // Gives a for loop and the commands under this loop will be followed. 
			{
				if (column.y == 0 && bird.x + bird.width / 2 > column.x + column.width / 2 - 10 && bird.x + bird.width / 2 < column.x + column.width / 2 + 10)// if command which involved the column, wht width of the bird and the column width
				{
					score++; // Doubles the score by using the ++ signs. 
				}

				if (column.intersects(bird))//This line of code bascially says how if the column or the red rectangles interfers with the bird(box) anywhere, then the game will be over. 
				{
					gameOver = true; // This will allow the game over variable to be true. In other words this will basically finish the game for the user.

					if (bird.x <= column.x)// if command for the action of the game
					{
						bird.x = column.x - bird.width; // this line of code will only run if the 'if' command above is satisfied 
                                                // the above line of code basically means that the bird in the x direction = to the column of the x direction - the width of the bird. 

					}
                                        else // else comand 
					{
						if (column.y != 0) // if command 
                                                    // the above line of code means that if the column.y is not equal to zero then 
						{
							bird.y = column.y - bird.height; // the bird in the y direction = to the columns minus the hight of the bird in the display screen. 
						}
						else if (bird.y < column.height)// else if comand if the bird in the y direction is less than the height of the column
						{
							bird.y = column.height;// then the bird is equal to the column height. 
						}
					}
				}
			}

			if (bird.y > HEIGHT - 120 || bird.y < 0) // if  command. This line of code basically says how if the y direction of the bird is greater than the hight - 120 or if the bird in the y direction is lessa than zero, The commands underneath will follow it. 
			{
				gameOver = true; // This line of code will only run if the above line of code is satisfied by the program. This line of code basically says that the game will be over if the if statment is true. 
			}

			if (bird.y + yMotion >= HEIGHT - 120) // This is a if command where the bird in the y direction and the y motion is greater than or equal to the height minus 120
			{
				bird.y = HEIGHT - 120 - bird.height; // This line of code will only happen if the above if statment is satisfied. This line of code basically says how if bird in the y direction = to the height - 120 
				gameOver = true;// Will finish the game if the above command's conditions are met. 
			}
		}

		renderer.repaint();
	}

	public void repaint(Graphics g) // This line of code allows the program to have graphics and allows the user to experience color 
	{
		g.setColor(Color.black); // Fills the background with black color. Can be changed by chaning to a recnoziable color as recognized by Java. 
		g.fillRect(0, 0, WIDTH, HEIGHT); // fills the entire screen, with the black color. (i.e. width the width and the height)

		g.setColor(Color.blue); // fills the bed color with blue 
		g.fillRect(0, HEIGHT - 120, WIDTH, 120); // fills the rectangle with the appropriate mesurements as mentioned with the numbers in the brackets. 

		g.setColor(Color.red); // fills the little bit of the bottom with red. 
		g.fillRect(0, HEIGHT - 120, WIDTH, 20); // fills the area with the appropriate mesurements as mentioned with the numbers in the brackets.

		g.setColor(Color.white); //fills the bird color with white. 
		g.fillRect(bird.x, bird.y, bird.width, bird.height); // Fills the bird rectangle by using the width, helight the x and y directions of the bird. 

		for (Rectangle column : columns)// for loop of the columns. 
		{
			paintColumn(g, column); // Paints the columns with the color mentioned above. 
		}

		g.setColor(Color.white); // Sets the font color for the text 
		g.setFont(new Font("Didgeree Doodle NF", 1, 100)); // sets the font for the text. In this case its airal and 100. This is done by the import of font at the beggining of the code

		if (!started)// this line of code contains the if command and only follows if the game has not started yet
		{
			g.drawString("Click to start!", 75, HEIGHT / 2 - 50); // Identifys and puts in place the text for the game frame. The text is click to start ans has beeing given the position
		}

		if (gameOver)// this line of code contains the if command and only follows if the game is over. 
		{
			g.drawString("Game Over!", 100, HEIGHT / 2 - 50); // Identifys and puts in place the game over. Same position as the game start text. 
		}

		if (!gameOver && started)// This is the if loop and shows how if the game is not over and the game has started, the underneath code will follow. 
		{
			g.drawString(String.valueOf(score), WIDTH / 2 - 25, 100); // this line of code basically displays the score of the game, and positions it based on the position gven by the numbers in the comand. 
		}
	}

// The below lines of code are the extensions for the action listener, mouse event, and the key event commands. Is considered as an extension for the action listener in this java program
	public static void main(String[] args)
	{
		flappyBird = new FlappyBird(); 
	}

	@Override
	public void mouseClicked(MouseEvent e)
	{
		jump();
	}

	@Override
	public void keyReleased(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			jump();
		}
	}
	
	@Override
	public void mousePressed(MouseEvent e)
	{
	}

	@Override
	public void mouseReleased(MouseEvent e)
	{
	}

	@Override
	public void mouseEntered(MouseEvent e)
	{
	}

	@Override
	public void mouseExited(MouseEvent e)
	{
	}

	@Override
	public void keyTyped(KeyEvent e)
	{

	}

        
	@Override
	public void keyPressed(KeyEvent e)
        {
            
        }

    private Object createImage(String string) 
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}

//About this project 
// This project contains two classes which consist of flappybird and renderer class itself
// It uses Jframe, J graphics, J panel, and java.awt.graphics to run the program. 

//Time Frame 
// This program took about three - four weeks to complete. 

//Challenges 
// This project was very  hard to make and create. The hardest part of this program was to find the right numbers in order for the game to run smoothly. 
// The other challenge was debugging and figuring the coding section of the public void action performer. 
// In the programing section it was hard to find the right key/import function to use in order for the game to work my way. 
// The programming initally also diplayed a lot of error because of the import function which was not corrected/imported  initally. 

//Future work 
// We also plan to improve this by adding image to the game, and also creating this game in GUI. 
