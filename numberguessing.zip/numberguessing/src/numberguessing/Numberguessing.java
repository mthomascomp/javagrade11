/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numberguessing;
import java.util.Scanner;
import java.lang.Math;
/**
 *
 * @author Lab26
 */
public class Numberguessing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int secretNumber;
            secretNumber = (int) (int)(20*Math.random()+1);
             
        Scanner keyboard = new Scanner(System.in);
            int guess;
         do{
            System.out.print("Enter a guess: ");
            guess = keyboard.nextInt();
            System.out.println("Your guess is " + guess);
            if (guess>20)
                System.out.println("The number can only be from 1- 20. Try Again");            
            if (guess == secretNumber)
                  System.out.println("Your guess is correct. Congratulations!");
            else if (guess < secretNumber)
                  System.out
                             .println("Your guess is too low than the secret number.");
            else if (guess > secretNumber)
                  System.out
                             .println("Your guess is too high than the secret number.");
    }while (guess != secretNumber);
    
}
}
